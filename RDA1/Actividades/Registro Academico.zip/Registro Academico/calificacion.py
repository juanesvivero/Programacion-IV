class Calificacion:
    # Constructor de la clase Calificacion
    def __init__(self, materia, nota):
        # Inicializar los atributos de la calificación
        self.materia = materia  # Materia en la que se asigna la calificación
        self.nota = nota        # Nota obtenida en la materia
